package com.murugavel.app.demoapp.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.murugavel.app.demoapp.service.CSVFileReaderService;
import com.murugavel.app.demoapp.service.WebCrawlerWithJSOUPService;

@RestController
public class TestController {

	@Autowired
	private WebCrawlerWithJSOUPService webCrawl;
	@Autowired
	private CSVFileReaderService csvFileRead;

	@RequestMapping(value = "/home/{data}")
	public String firstPage(@PathVariable String data) {
		return "Hi da" + data;
	}

	@RequestMapping(value = "/webcrawl")
	public ModelAndView doWebCrawl(@RequestParam(required = false) String url) throws IOException {
		ModelAndView m = new ModelAndView();
		if (url == null) {
			url = "https://www.amazon.com";
		}
		String heading1 = url;
		m.addObject("heading", heading1);
		m.setViewName("webcrawl");
		System.out.println(url);
//		System.out.println(webCrawl.testing());
		m.addObject("links", webCrawl.allLinks(url));
		return m;

	}

	@RequestMapping(value = "/csvtojson")
	public ModelAndView csvFileToJSON(@RequestParam(required = false) String filename) {
		ModelAndView m = new ModelAndView();
		if (filename == null) {
			filename = "src/default.csv";
		}
		m.setViewName("csvtojson");
//		m.addObject("links", .allLinks(url));
		csvFileRead.csvFileRead(filename);
		return m;

	}
}
