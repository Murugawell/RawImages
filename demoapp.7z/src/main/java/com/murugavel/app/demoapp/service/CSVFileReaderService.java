package com.murugavel.app.demoapp.service;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.List;

import org.springframework.stereotype.Service;

import com.opencsv.CSVReader;

@Service
public class CSVFileReaderService {

	public void csvFileRead(String file) {
		try {
			System.out.println(file);
			File fi=new File(file);
			fi.mkdirs();
			FileReader fr = new FileReader(fi);
			CSVReader csvReader = new CSVReader(fr);
			List<String[]> allData = csvReader.readAll();
			String[] headers = allData.get(0);
			System.out.println("Column" + headers);
			for (String[] row : allData) {
				for (String cell : row) {

				}
			}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}
}
