package com.murugavel.app.demoapp.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.stereotype.Service;

@Service()
public class WebCrawlerService {

	public Queue<String> queue = new LinkedList<>();
	public Set<String> markedUrl = new HashSet<>();
	public String regEx = "http[s]*://(\\w+\\.)*(\\w+)";

	public String testing() {
		try {
			webCrawl("https://www.amazon.com");
			showResults();
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
		return "Data from Service";
	}

	public List<String> allLinks(String url) throws IOException {
		List<String> ls = new LinkedList<>();
		Document doc = Jsoup.connect(url).get();
		Elements titles = doc.select(".entrytitle");

		// print all titles in main page
		for (Element e : titles) {
			System.out.println("text: " + e.text());
			System.out.println("html: " + e.html());
		}

		// print all available links on page
		Elements links = doc.select("a[href]");
		for (Element l : links) {
			System.out.println("link: " + l.attr("abs:href"));
			ls.add(l.attr("abs:href"));
		}

		return ls;
	}

	public void webCrawl(String root) throws IOException {
		queue.add(root);
		BufferedReader br = null;

		while (!queue.isEmpty()) {
			String crawledUrl = queue.poll();
			System.out.println("\n Sites crawled:::" + crawledUrl + "==");

			if (markedUrl.size() > 10) {
				return;
			}

			boolean ok = false;
			URL url = null;

			while (!ok && crawledUrl != null) {
				try {
					System.out.println(crawledUrl);
					url = new URL(crawledUrl);
					br = new BufferedReader(new InputStreamReader(url.openStream()));
					ok = true;
				} catch (MalformedURLException me) {
					// TODO: handle exception
					System.out.println("Malformed url:" + crawledUrl);
					crawledUrl = queue.poll();
//					ok = false;
				} catch (IOException e) {
					// TODO: handle exception
					System.out.println("IOException url:" + crawledUrl);
					crawledUrl = queue.poll();
//					ok = false;
				} catch (Exception e) {
					// TODO: handle exception
					System.out.println("Exception url:" + crawledUrl);

				}
			}

			StringBuilder sb = new StringBuilder();
			String tmp = null;
			while ((tmp = br.readLine()) != null) {
				sb.append(tmp);
			}
			tmp = sb.toString();
			System.out.println(sb);
			Pattern pattern = Pattern.compile(regEx);
			Matcher matcher = pattern.matcher(tmp);

			while (matcher.find()) {
				String w = matcher.group();
				System.out.println(w);
				if (!markedUrl.contains(w)) {
					markedUrl.add(w);
					System.out.println("Site added for crawling:" + w);
					queue.add(w);
				}
			}

		}
		if (br != null) {
			br.close();
		}
	}

	public void showResults() {
		System.out.println("\nResults");
		System.out.println("\nWeb sites crawled :" + markedUrl.size() + "\n");
		for (String string : markedUrl) {
			System.out.println(string);
		}
	}
}
